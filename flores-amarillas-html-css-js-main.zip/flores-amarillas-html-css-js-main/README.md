# ✅ 5 PROYECTOS DE FLORES AMARILLAS CON HTML CSS JS Y PYTHON 🌻
### Video del tutorial: [https://youtu.be/aqTGkz7caF0](https://youtu.be/aqTGkz7caF0)
![image](https://github.com/user-attachments/assets/bba8eed7-e7fa-409b-988a-c67fb5547d5e)
